import React, { useEffect, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './lib/firebase';
import { sha256Hex } from './lib/crypto';
import { DEFAULT_GIFT, DEFAULT_PASSCODE } from './lib/defaultGift';
import { BirthdayGift, GiftStage } from './types/gift';
import { ErrorBoundary } from './components/ErrorBoundary';
import { StageLogin } from './components/StageLogin';
import { StageEnvelope } from './components/StageEnvelope';
import { StageMenu } from './components/StageMenu';
import { StageMessage } from './components/StageMessage';
import { StageFlower } from './components/StageFlower';
import { StageGallery } from './components/StageGallery';
import { CreatorStudioModal } from './components/CreatorStudioModal';

function BirthdayGiftApp() {
  const [gift, setGift] = useState<BirthdayGift>(DEFAULT_GIFT);
  const [loadingGift, setLoadingGift] = useState<boolean>(false);
  const [giftLoadError, setGiftLoadError] = useState<string | null>(null);
  const [stage, setStage] = useState<GiftStage>('login');
  const [studioOpen, setStudioOpen] = useState<boolean>(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const giftId = params.get('gift');
    if (!giftId || !/^[a-zA-Z0-9_-]{2,64}$/.test(giftId)) {
      return;
    }

    let cancelled = false;
    async function loadSharedGift(id: string) {
      setLoadingGift(true);
      setGiftLoadError(null);
      const docPath = `gifts/${id}`;
      try {
        const snap = await getDoc(doc(db, 'gifts', id));
        if (cancelled) return;
        if (snap.exists()) {
          setGift(snap.data() as BirthdayGift);
        } else {
          setGiftLoadError(
            'Tautan kado tidak ditemukan di database, menampilkan template kado bawaan.'
          );
        }
      } catch (error) {
        if (!cancelled) {
          handleFirestoreError(error, OperationType.GET, docPath);
        }
      } finally {
        if (!cancelled) {
          setLoadingGift(false);
        }
      }
    }

    void loadSharedGift(giftId);
    return () => {
      cancelled = true;
    };
  }, []);

  async function handleUnlock(inputPassword: string): Promise<boolean> {
    const trimmed = inputPassword.trim();
    if (gift.passcodeHash) {
      const digest = await sha256Hex(trimmed);
      if (digest === gift.passcodeHash) {
        setStage('envelope');
        return true;
      }
      return false;
    }

    if (trimmed === DEFAULT_PASSCODE) {
      setStage('envelope');
      return true;
    }
    return false;
  }

  function handleSelectPreviewGift(updated: BirthdayGift) {
    setGift(updated);
    const nextUrl = new URL(window.location.href);
    nextUrl.searchParams.set('gift', updated.id);
    window.history.replaceState({}, '', nextUrl.toString());
  }

  return (
    <>
      {stage === 'login' && (
        <StageLogin
          gift={gift}
          loadingGift={loadingGift}
          giftLoadError={giftLoadError}
          onUnlock={handleUnlock}
          onOpenStudio={() => setStudioOpen(true)}
        />
      )}

      {stage === 'envelope' && (
        <StageEnvelope
          title={gift.envelopeTitle}
          recipientName={gift.recipientName}
          onOpened={() => setStage('menu')}
        />
      )}

      {stage === 'menu' && (
        <StageMenu
          title={gift.menuTitle}
          recipientName={gift.recipientName}
          onSelectStage={(next) => setStage(next)}
          onLockGift={() => setStage('login')}
          onOpenStudio={() => setStudioOpen(true)}
        />
      )}

      {stage === 'message' && (
        <StageMessage
          letterTitle={gift.letterTitle}
          letterBody={gift.letterBody}
          senderName={gift.senderName}
          onBack={() => setStage('menu')}
        />
      )}

      {stage === 'flower' && (
        <StageFlower
          compliments={gift.flowerCompliments}
          onBack={() => setStage('menu')}
        />
      )}

      {stage === 'gallery' && (
        <StageGallery
          memories={gift.memories}
          musicTitle={gift.musicTitle}
          musicSource={gift.musicSource}
          musicUrl={gift.musicUrl}
          onBack={() => setStage('menu')}
        />
      )}

      <CreatorStudioModal
        open={studioOpen}
        activeGift={gift}
        onClose={() => setStudioOpen(false)}
        onSelectGiftForPreview={handleSelectPreviewGift}
      />
    </>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <BirthdayGiftApp />
    </ErrorBoundary>
  );
}
