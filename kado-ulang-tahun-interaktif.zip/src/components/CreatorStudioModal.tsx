import React, { useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  Check,
  Copy,
  LogIn,
  LogOut,
  Plus,
  Save,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { compressImageToDataUrl, sha256Hex } from '../lib/crypto';
import {
  DEFAULT_GIFT,
  DEFAULT_MEMORIES,
  DEFAULT_PASSCODE,
  sanitizeGiftForFirestore,
} from '../lib/defaultGift';
import { BirthdayGift, MemoryItem, PresetArt } from '../types/gift';

interface CreatorStudioModalProps {
  open: boolean;
  activeGift: BirthdayGift;
  onClose: () => void;
  onSelectGiftForPreview: (gift: BirthdayGift) => void;
}

function createBlankDraft(uid: string): BirthdayGift {
  const randomSuffix = Math.random().toString(36).slice(2, 7);
  return {
    ...DEFAULT_GIFT,
    id: `kado-${randomSuffix}`,
    ownerId: uid,
    memories: DEFAULT_MEMORIES.map((m) => ({ ...m })),
    flowerCompliments: [...DEFAULT_GIFT.flowerCompliments],
  };
}

export function CreatorStudioModal({
  open,
  activeGift,
  onClose,
  onSelectGiftForPreview,
}: CreatorStudioModalProps) {
  const [user, setUser] = useState<User | null>(auth.currentUser);
  const [authLoading, setAuthLoading] = useState(false);
  const [myGifts, setMyGifts] = useState<BirthdayGift[]>([]);
  const [loadingGifts, setLoadingGifts] = useState(false);

  const [draft, setDraft] = useState<BirthdayGift>(activeGift);
  const [isExistingDoc, setIsExistingDoc] = useState(false);
  const [newPasscode, setNewPasscode] = useState('');
  const [saving, setSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!open || !user) return;
    void loadUserGifts(user.uid);
  }, [open, user]);

  async function loadUserGifts(uid: string) {
    setLoadingGifts(true);
    setErrorMessage('');
    const path = 'gifts';
    try {
      const q = query(collection(db, path), where('ownerId', '==', uid));
      const snap = await getDocs(q);
      const list: BirthdayGift[] = snap.docs.map((d) => d.data() as BirthdayGift);
      setMyGifts(list);
      if (list.length > 0 && !isExistingDoc) {
        const currentMatch = list.find((g) => g.id === activeGift.id);
        if (currentMatch) {
          setDraft(currentMatch);
          setIsExistingDoc(true);
        }
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    } finally {
      setLoadingGifts(false);
    }
  }

  async function handleSignIn() {
    setAuthLoading(true);
    setErrorMessage('');
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        setDraft((prev) => ({
          ...prev,
          id:
            prev.id === DEFAULT_GIFT.id
              ? `kado-${Math.random().toString(36).slice(2, 7)}`
              : prev.id,
          ownerId: result.user.uid,
        }));
      }
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Gagal masuk dengan Google.'
      );
    } finally {
      setAuthLoading(false);
    }
  }

  async function handleSignOut() {
    await signOut(auth);
    setMyGifts([]);
    setIsExistingDoc(false);
  }

  function handleStartNewGift() {
    if (!user) return;
    setDraft(createBlankDraft(user.uid));
    setIsExistingDoc(false);
    setNewPasscode('');
    setStatusMessage('');
    setErrorMessage('');
  }

  function handleSelectGiftToEdit(gift: BirthdayGift) {
    setDraft(gift);
    setIsExistingDoc(true);
    setNewPasscode('');
    setStatusMessage('');
    setErrorMessage('');
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;

    const cleanedPin = newPasscode.replace(/\D/g, '');
    if (cleanedPin.length > 0 && cleanedPin.length !== 6) {
      setErrorMessage('PIN harus terdiri dari tepat 6 digit angka.');
      return;
    }

    setSaving(true);
    setStatusMessage('');
    setErrorMessage('');

    try {
      let passcodeHash = draft.passcodeHash;
      if (cleanedPin.length === 6) {
        passcodeHash = await sha256Hex(cleanedPin);
      } else if (!passcodeHash) {
        passcodeHash = await sha256Hex(DEFAULT_PASSCODE);
      }

      const cleanPayload = sanitizeGiftForFirestore(draft, user.uid, passcodeHash);
      const docPath = `gifts/${cleanPayload.id}`;
      const ref = doc(db, 'gifts', cleanPayload.id);

      if (isExistingDoc) {
        await updateDoc(ref, {
          recipientName: cleanPayload.recipientName,
          senderName: cleanPayload.senderName,
          passcodeHash: cleanPayload.passcodeHash,
          passcodeHint: cleanPayload.passcodeHint,
          envelopeTitle: cleanPayload.envelopeTitle,
          menuTitle: cleanPayload.menuTitle,
          letterTitle: cleanPayload.letterTitle,
          letterBody: cleanPayload.letterBody,
          flowerCompliments: cleanPayload.flowerCompliments,
          memories: cleanPayload.memories,
          musicTitle: cleanPayload.musicTitle,
          musicSource: cleanPayload.musicSource,
          musicUrl: cleanPayload.musicUrl,
          updatedAt: serverTimestamp(),
        });
      } else {
        await setDoc(ref, {
          ...cleanPayload,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        setIsExistingDoc(true);
      }

      const updatedGift: BirthdayGift = { ...cleanPayload };
      setDraft(updatedGift);
      setNewPasscode('');
      setStatusMessage('Kado berhasil disimpan ke Firebase Firestore.');
      onSelectGiftForPreview(updatedGift);
      await loadUserGifts(user.uid);
    } catch (error) {
      handleFirestoreError(
        error,
        isExistingDoc ? OperationType.UPDATE : OperationType.CREATE,
        `gifts/${draft.id}`
      );
    } finally {
      setSaving(false);
    }
  }

  async function handleDeleteGift(giftId: string) {
    if (!user) return;
    const path = `gifts/${giftId}`;
    try {
      await deleteDoc(doc(db, 'gifts', giftId));
      setStatusMessage('Kado dihapus dari Firestore.');
      if (draft.id === giftId) {
        handleStartNewGift();
      }
      await loadUserGifts(user.uid);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }

  function handleCopyShareLink(giftId: string) {
    const url = `${window.location.origin}${window.location.pathname}?gift=${encodeURIComponent(
      giftId
    )}`;
    void navigator.clipboard.writeText(url);
    setCopiedId(giftId);
    window.setTimeout(() => setCopiedId(null), 2000);
  }

  function updateCompliment(index: number, value: string) {
    setDraft((prev) => {
      const next = [...prev.flowerCompliments];
      next[index] = value;
      return { ...prev, flowerCompliments: next };
    });
  }

  function addCompliment() {
    if (draft.flowerCompliments.length >= 6) return;
    setDraft((prev) => ({
      ...prev,
      flowerCompliments: [...prev.flowerCompliments, 'You are amazing!'],
    }));
  }

  function removeCompliment(index: number) {
    if (draft.flowerCompliments.length <= 1) return;
    setDraft((prev) => ({
      ...prev,
      flowerCompliments: prev.flowerCompliments.filter((_, i) => i !== index),
    }));
  }

  function updateMemory(index: number, patch: Partial<MemoryItem>) {
    setDraft((prev) => {
      const next = [...prev.memories];
      next[index] = { ...next[index], ...patch };
      return { ...prev, memories: next };
    });
  }

  async function handleUploadMemoryPhoto(index: number, file?: File) {
    if (!file) return;
    try {
      const compressed = await compressImageToDataUrl(file);
      updateMemory(index, { presetArt: 'custom', imageData: compressed });
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Gagal memproses foto.'
      );
    }
  }

  function addMemory() {
    if (draft.memories.length >= 6) return;
    setDraft((prev) => ({
      ...prev,
      memories: [
        ...prev.memories,
        {
          id: `mem-${Date.now().toString(36)}`,
          caption: 'Kenangan Baru',
          dateLabel: 'Hari Spesial',
          presetArt: 'stars',
          imageData: '',
        },
      ],
    }));
  }

  function removeMemory(index: number) {
    if (draft.memories.length <= 1) return;
    setDraft((prev) => ({
      ...prev,
      memories: prev.memories.filter((_, i) => i !== index),
    }));
  }

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="studio-title"
    >
      <div className="w-full max-w-4xl max-h-[90vh] bg-[#FAF6EE] text-[#241617] rounded-2xl shadow-2xl border border-[#7A1318]/15 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-white border-b border-[#E5DAC8] flex items-center justify-between gap-4">
          <div>
            <h2 id="studio-title" className="font-display text-2xl text-[#7A1318]">
              Studio Pembuat Kado
            </h2>
            <p className="text-xs text-[#5C4546]">
              Sesuaikan isi kado dan simpan langsung ke Firebase Firestore.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup Studio"
            className="w-9 h-9 rounded-lg border border-[#E5DAC8] flex items-center justify-center text-[#5C4546] hover:text-[#7A1318] hover:bg-[#FAF6EE] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {!user ? (
            <div className="bg-white rounded-xl p-8 border border-[#E5DAC8] text-center max-w-lg mx-auto space-y-4">
              <h3 className="font-display text-2xl text-[#7A1318]">
                Masuk untuk Menyimpan ke Firebase
              </h3>
              <p className="text-sm text-[#5C4546] leading-relaxed">
                Masuk dengan akun Google agar kamu bisa membuat kado ulang tahun pribadi,
                mengatur PIN rahasia 6 digit, mengunggah foto kenangan, dan membagikan tautan
                khusus ke penerima.
              </p>
              {errorMessage && (
                <p className="text-xs text-[#B41E25] bg-[#FDF2F2] py-2 px-3 rounded-lg">
                  {errorMessage}
                </p>
              )}
              <button
                type="button"
                onClick={handleSignIn}
                disabled={authLoading}
                className="inline-flex items-center justify-center gap-2 py-2.5 px-6 rounded-xl bg-[#7A1318] text-[#FAF6EE] text-sm font-semibold hover:bg-[#5E0E12] disabled:opacity-60 transition-colors whitespace-nowrap cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>{authLoading ? 'Menghubungkan...' : 'Masuk dengan Google'}</span>
              </button>
            </div>
          ) : (
            <>
              {/* Account & My Gifts Switcher */}
              <div className="bg-white rounded-xl p-5 border border-[#E5DAC8] space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="text-sm">
                    <span className="text-[#5C4546]">Masuk sebagai </span>
                    <span className="font-semibold text-[#241617]">
                      {user.displayName || user.email}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleStartNewGift}
                      className="inline-flex items-center gap-1.5 py-2 px-3.5 rounded-lg bg-[#7A1318] text-[#FAF6EE] text-xs font-semibold hover:bg-[#5E0E12] whitespace-nowrap cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Kado Baru</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleSignOut}
                      className="inline-flex items-center gap-1.5 py-2 px-3.5 rounded-lg border border-[#E5DAC8] text-xs font-medium text-[#5C4546] hover:text-[#7A1318] whitespace-nowrap cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Keluar</span>
                    </button>
                  </div>
                </div>

                {loadingGifts ? (
                  <p className="text-xs text-[#5C4546]">Memuat daftar kado tersimpan...</p>
                ) : myGifts.length > 0 ? (
                  <div className="space-y-2 pt-2 border-t border-[#EFE7DA]">
                    <p className="text-xs font-medium text-[#5C4546]">
                      Kado Tersimpan Milikmu ({myGifts.length})
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {myGifts.map((item) => {
                        const selected = isExistingDoc && draft.id === item.id;
                        return (
                          <div
                            key={item.id}
                            className={`flex items-center justify-between gap-2 p-3 rounded-lg border ${
                              selected
                                ? 'border-[#7A1318] bg-[#FAF4F0]'
                                : 'border-[#E5DAC8] bg-[#FAF6EE]/50'
                            }`}
                          >
                            <button
                              type="button"
                              onClick={() => handleSelectGiftToEdit(item)}
                              className="text-left min-w-0 flex-1 cursor-pointer"
                            >
                              <p className="text-sm font-semibold text-[#7A1318] truncate">
                                Untuk: {item.recipientName}
                              </p>
                              <p className="text-xs text-[#5C4546] truncate">
                                ID: {item.id}
                              </p>
                            </button>
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleCopyShareLink(item.id)}
                                title="Salin tautan kado"
                                className="p-2 rounded-md text-[#7A1318] hover:bg-white cursor-pointer"
                              >
                                {copiedId === item.id ? (
                                  <Check className="w-4 h-4 text-emerald-700" />
                                ) : (
                                  <Copy className="w-4 h-4" />
                                )}
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteGift(item.id)}
                                title="Hapus kado"
                                className="p-2 rounded-md text-[#B41E25] hover:bg-white cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-[#5C4546]">
                    Belum ada kado tersimpan. Isi formulir di bawah lalu simpan untuk membuat
                    tautan kado pertamamu.
                  </p>
                )}
              </div>

              {/* Editor Form */}
              <form id="gift-editor-form" onSubmit={handleSave} className="space-y-6">
                {statusMessage && (
                  <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-medium flex flex-wrap items-center justify-between gap-2">
                    <span>{statusMessage}</span>
                    <button
                      type="button"
                      onClick={() => handleCopyShareLink(draft.id)}
                      className="inline-flex items-center gap-1.5 underline font-semibold cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>Salin Link Kado</span>
                    </button>
                  </div>
                )}

                {errorMessage && (
                  <div className="p-3.5 rounded-xl bg-[#FDF2F2] border border-[#C42B33]/30 text-[#8B151B] text-xs font-medium">
                    {errorMessage}
                  </div>
                )}

                {/* Identity & PIN */}
                <div className="bg-white rounded-xl p-5 border border-[#E5DAC8] space-y-4">
                  <h3 className="font-display text-xl text-[#7A1318]">
                    1. Identitas &amp; PIN Kado
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <label className="block space-y-1.5">
                      <span className="text-xs font-medium text-[#5C4546]">ID Tautan Kado</span>
                      <input
                        type="text"
                        required
                        disabled={isExistingDoc}
                        value={draft.id}
                        onChange={(e) =>
                          setDraft((p) => ({
                            ...p,
                            id: e.target.value.replace(/[^a-zA-Z0-9_-]/g, '-'),
                          }))
                        }
                        maxLength={64}
                        className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] text-sm disabled:bg-[#F3EDE2]"
                      />
                    </label>
                    <label className="block space-y-1.5">
                      <span className="text-xs font-medium text-[#5C4546]">
                        {isExistingDoc
                          ? 'PIN Baru 6 Digit (kosongkan jika tetap)'
                          : 'PIN Pembuka Kado (6 digit angka)'}
                      </span>
                      <input
                        type="text"
                        inputMode="numeric"
                        maxLength={6}
                        value={newPasscode}
                        onChange={(e) => setNewPasscode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        placeholder={
                          isExistingDoc ? 'Biarkan kosong jika tidak diubah' : 'Default: 123456'
                        }
                        className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] text-sm tabular-nums tracking-widest"
                      />
                    </label>
                    <label className="block space-y-1.5">
                      <span className="text-xs font-medium text-[#5C4546]">Nama Penerima</span>
                      <input
                        type="text"
                        required
                        maxLength={80}
                        value={draft.recipientName}
                        onChange={(e) =>
                          setDraft((p) => ({ ...p, recipientName: e.target.value }))
                        }
                        className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] text-sm"
                      />
                    </label>
                    <label className="block space-y-1.5">
                      <span className="text-xs font-medium text-[#5C4546]">Nama Pengirim</span>
                      <input
                        type="text"
                        required
                        maxLength={80}
                        value={draft.senderName}
                        onChange={(e) =>
                          setDraft((p) => ({ ...p, senderName: e.target.value }))
                        }
                        className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] text-sm"
                      />
                    </label>
                  </div>
                  <label className="block space-y-1.5">
                    <span className="text-xs font-medium text-[#5C4546]">
                      Petunjuk PIN (Opsional)
                    </span>
                    <input
                      type="text"
                      maxLength={120}
                      value={draft.passcodeHint}
                      onChange={(e) =>
                        setDraft((p) => ({ ...p, passcodeHint: e.target.value }))
                      }
                      className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] text-sm"
                    />
                  </label>
                </div>

                {/* Titles & Letter */}
                <div className="bg-white rounded-xl p-5 border border-[#E5DAC8] space-y-4">
                  <h3 className="font-display text-xl text-[#7A1318]">2. Surat Ucapan</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <label className="block space-y-1.5">
                      <span className="text-xs font-medium text-[#5C4546]">Judul Amplop</span>
                      <input
                        type="text"
                        required
                        maxLength={80}
                        value={draft.envelopeTitle}
                        onChange={(e) =>
                          setDraft((p) => ({ ...p, envelopeTitle: e.target.value }))
                        }
                        className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] text-sm"
                      />
                    </label>
                    <label className="block space-y-1.5">
                      <span className="text-xs font-medium text-[#5C4546]">Judul Menu</span>
                      <input
                        type="text"
                        required
                        maxLength={80}
                        value={draft.menuTitle}
                        onChange={(e) =>
                          setDraft((p) => ({ ...p, menuTitle: e.target.value }))
                        }
                        className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] text-sm"
                      />
                    </label>
                    <label className="block space-y-1.5">
                      <span className="text-xs font-medium text-[#5C4546]">Sapaan Surat</span>
                      <input
                        type="text"
                        required
                        maxLength={80}
                        value={draft.letterTitle}
                        onChange={(e) =>
                          setDraft((p) => ({ ...p, letterTitle: e.target.value }))
                        }
                        className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] text-sm"
                      />
                    </label>
                  </div>
                  <label className="block space-y-1.5">
                    <span className="text-xs font-medium text-[#5C4546]">Isi Pesan Ulang Tahun</span>
                    <textarea
                      required
                      rows={5}
                      maxLength={3000}
                      value={draft.letterBody}
                      onChange={(e) =>
                        setDraft((p) => ({ ...p, letterBody: e.target.value }))
                      }
                      className="w-full px-3.5 py-2.5 rounded-lg border border-[#DFD5C5] text-sm leading-relaxed"
                    />
                  </label>
                </div>

                {/* Flower Compliments */}
                <div className="bg-white rounded-xl p-5 border border-[#E5DAC8] space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-display text-xl text-[#7A1318]">
                      3. Pesan Buket Bunga ({draft.flowerCompliments.length}/6)
                    </h3>
                    {draft.flowerCompliments.length < 6 && (
                      <button
                        type="button"
                        onClick={addCompliment}
                        className="inline-flex items-center gap-1 py-1.5 px-3 rounded-lg border border-[#7A1318]/25 text-xs font-medium text-[#7A1318] hover:bg-[#FAF6EE] cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Tambah</span>
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {draft.flowerCompliments.map((text, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <input
                          type="text"
                          required
                          maxLength={120}
                          value={text}
                          onChange={(e) => updateCompliment(idx, e.target.value)}
                          className="flex-1 px-3 py-2 rounded-lg border border-[#DFD5C5] text-sm"
                        />
                        {draft.flowerCompliments.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeCompliment(idx)}
                            aria-label="Hapus pesan bunga"
                            className="p-2 rounded-lg text-[#B41E25] hover:bg-[#FDF2F2] cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Polaroid Memories */}
                <div className="bg-white rounded-xl p-5 border border-[#E5DAC8] space-y-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-display text-xl text-[#7A1318]">
                      4. Galeri Polaroid ({draft.memories.length}/6)
                    </h3>
                    {draft.memories.length < 6 && (
                      <button
                        type="button"
                        onClick={addMemory}
                        className="inline-flex items-center gap-1 py-1.5 px-3 rounded-lg border border-[#7A1318]/25 text-xs font-medium text-[#7A1318] hover:bg-[#FAF6EE] cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Tambah Foto</span>
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {draft.memories.map((mem, idx) => (
                      <div
                        key={mem.id}
                        className="p-3.5 rounded-xl border border-[#E5DAC8] bg-[#FAF6EE]/50 space-y-3"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-semibold text-[#7A1318]">
                            Polaroid {idx + 1}
                          </span>
                          {draft.memories.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeMemory(idx)}
                              className="text-xs text-[#B41E25] hover:underline cursor-pointer"
                            >
                              Hapus
                            </button>
                          )}
                        </div>
                        <input
                          type="text"
                          required
                          maxLength={120}
                          value={mem.caption}
                          onChange={(e) => updateMemory(idx, { caption: e.target.value })}
                          placeholder="Judul kenangan"
                          className="w-full px-3 py-1.5 rounded-lg border border-[#DFD5C5] bg-white text-sm"
                        />
                        <input
                          type="text"
                          maxLength={40}
                          value={mem.dateLabel}
                          onChange={(e) => updateMemory(idx, { dateLabel: e.target.value })}
                          placeholder="Tanggal / keterangan singkat"
                          className="w-full px-3 py-1.5 rounded-lg border border-[#DFD5C5] bg-white text-sm"
                        />
                        <div className="flex items-center gap-2">
                          <select
                            value={mem.presetArt}
                            onChange={(e) =>
                              updateMemory(idx, {
                                presetArt: e.target.value as PresetArt,
                              })
                            }
                            className="flex-1 px-3 py-1.5 rounded-lg border border-[#DFD5C5] bg-white text-xs"
                          >
                            <option value="cake">Ilustrasi Kue Ulang Tahun</option>
                            <option value="sunset">Ilustrasi Senja</option>
                            <option value="coffee">Ilustrasi Kopi Hangat</option>
                            <option value="stars">Ilustrasi Malam Berbintang</option>
                            {mem.imageData && <option value="custom">Foto Unggahan Sendiri</option>}
                          </select>
                          <label className="inline-flex items-center gap-1.5 py-1.5 px-3 rounded-lg bg-white border border-[#7A1318]/25 text-xs font-medium text-[#7A1318] cursor-pointer hover:bg-[#FAF6EE] whitespace-nowrap">
                            <Upload className="w-3.5 h-3.5" />
                            <span>Unggah Foto</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) =>
                                void handleUploadMemoryPhoto(idx, e.target.files?.[0])
                              }
                            />
                          </label>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Music */}
                <div className="bg-white rounded-xl p-5 border border-[#E5DAC8] space-y-4">
                  <h3 className="font-display text-xl text-[#7A1318]">5. Musik Piringan Hitam</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <label className="block space-y-1.5">
                      <span className="text-xs font-medium text-[#5C4546]">Judul Lagu</span>
                      <input
                        type="text"
                        required
                        maxLength={100}
                        value={draft.musicTitle}
                        onChange={(e) =>
                          setDraft((p) => ({ ...p, musicTitle: e.target.value }))
                        }
                        className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] text-sm"
                      />
                    </label>
                    <label className="block space-y-1.5">
                      <span className="text-xs font-medium text-[#5C4546]">Sumber Audio</span>
                      <select
                        value={draft.musicSource}
                        onChange={(e) =>
                          setDraft((p) => ({
                            ...p,
                            musicSource: e.target.value as 'melody' | 'custom_url',
                          }))
                        }
                        className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] bg-white text-sm"
                      >
                        <option value="melody">Melodi Kotak Musik Bawaan</option>
                        <option value="custom_url">Tautan MP3 Kustom</option>
                      </select>
                    </label>
                  </div>
                  {draft.musicSource === 'custom_url' && (
                    <label className="block space-y-1.5">
                      <span className="text-xs font-medium text-[#5C4546]">URL File MP3</span>
                      <input
                        type="url"
                        maxLength={500}
                        value={draft.musicUrl}
                        onChange={(e) =>
                          setDraft((p) => ({ ...p, musicUrl: e.target.value }))
                        }
                        placeholder="https://..."
                        className="w-full px-3.5 py-2 rounded-lg border border-[#DFD5C5] text-sm"
                      />
                    </label>
                  )}
                </div>
              </form>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-white border-t border-[#E5DAC8] flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="py-2 px-4 rounded-lg border border-[#DFD5C5] text-sm font-medium text-[#5C4546] hover:text-[#241617] whitespace-nowrap cursor-pointer"
          >
            Tutup
          </button>
          {user && (
            <button
              type="submit"
              form="gift-editor-form"
              disabled={saving}
              className="inline-flex items-center gap-2 py-2 px-5 rounded-lg bg-[#7A1318] text-[#FAF6EE] text-sm font-semibold hover:bg-[#5E0E12] disabled:opacity-60 transition-colors whitespace-nowrap cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Menyimpan...' : 'Simpan ke Firebase'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
