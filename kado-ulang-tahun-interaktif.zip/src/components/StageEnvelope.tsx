import React, { useState } from 'react';
import { motion } from 'motion/react';
import { WaxSealEmblem } from './Artwork';

interface StageEnvelopeProps {
  title: string;
  recipientName: string;
  onOpened: () => void;
}

export function StageEnvelope({ title, recipientName, onOpened }: StageEnvelopeProps) {
  const [isOpening, setIsOpening] = useState(false);

  function handleOpen() {
    if (isOpening) return;
    setIsOpening(true);
    window.setTimeout(() => {
      onOpened();
    }, 1500);
  }

  return (
    <div className="min-h-screen w-full bg-[#F6F1E7] text-[#241617] flex flex-col items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
        className="text-center max-w-lg w-full"
      >
        <p className="text-xs font-medium text-[#7A1318]/80 mb-2">
          Kado Spesial untuk {recipientName}
        </p>

        <h1 className="font-display italic text-5xl sm:text-6xl text-[#7A1318] mb-10 text-balance">
          {title}
        </h1>

        <button
          type="button"
          onClick={handleOpen}
          aria-label="Klik segel lilin untuk membuka amplop"
          className="group relative mx-auto block w-[300px] sm:w-[340px] h-[210px] sm:h-[230px] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-8 focus-visible:outline-[#7A1318] rounded-lg"
        >
          {/* Envelope back */}
          <div className="absolute inset-0 rounded-lg bg-[#8E161D] shadow-[0_22px_45px_rgba(107,15,22,0.28)]" />

          {/* Rising letter card */}
          <motion.div
            initial={{ y: 12 }}
            animate={isOpening ? { y: -58 } : { y: 8 }}
            transition={{ duration: 0.75, delay: isOpening ? 0.35 : 0, ease: [0.16, 1, 0.3, 1] }}
            className="absolute left-4 right-4 top-4 bottom-4 rounded-md bg-[#FAF6EE] border border-[#E5DAC8] shadow-sm flex flex-col items-center justify-center px-5"
          >
            <p className="font-display italic text-xl text-[#7A1318]">For {recipientName}</p>
            <span className="mt-2 h-px w-16 bg-[#7A1318]/25" />
          </motion.div>

          {/* Envelope side and bottom pockets */}
          <div
            className="absolute inset-0 rounded-b-lg pointer-events-none"
            style={{
              clipPath: 'polygon(0 0, 50% 54%, 100% 0, 100% 100%, 0 100%)',
              backgroundColor: '#A91D26',
            }}
          />
          <div
            className="absolute inset-0 rounded-b-lg pointer-events-none"
            style={{
              clipPath: 'polygon(0 100%, 50% 48%, 100% 100%)',
              backgroundColor: '#BA252E',
            }}
          />

          {/* Top flap */}
          <motion.div
            initial={{ rotateX: 0 }}
            animate={isOpening ? { rotateX: 180, zIndex: 1 } : { rotateX: 0, zIndex: 15 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            style={{
              transformOrigin: 'top center',
              transformStyle: 'preserve-3d',
              clipPath: 'polygon(0 0, 100% 0, 50% 56%)',
            }}
            className="absolute inset-0 rounded-t-lg bg-[#C92B35] pointer-events-none"
          />

          {/* Wax seal */}
          <motion.div
            animate={
              isOpening
                ? { opacity: 0, scale: 0.8, y: -12 }
                : { opacity: 1, scale: 1, y: 0 }
            }
            transition={{ duration: 0.35 }}
            className="absolute left-1/2 top-[48%] -translate-x-1/2 -translate-y-1/2 z-20 transition-transform duration-200 group-hover:scale-110"
          >
            <WaxSealEmblem className="w-16 h-16 drop-shadow-md" />
          </motion.div>
        </button>

        <p className="font-display italic text-xl text-[#5C4546] mt-8">
          {isOpening ? 'Membuka amplop...' : 'Klik segel lilin untuk membuka'}
        </p>
      </motion.div>
    </div>
  );
}
