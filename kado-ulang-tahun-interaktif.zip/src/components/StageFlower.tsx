import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft } from 'lucide-react';
import { BouquetIllustration } from './Artwork';

interface StageFlowerProps {
  compliments: string[];
  onBack: () => void;
}

export function StageFlower({ compliments, onBack }: StageFlowerProps) {
  const [bloomed, setBloomed] = useState(false);

  const leftItems = compliments.filter((_, i) => i % 2 === 0);
  const rightItems = compliments.filter((_, i) => i % 2 === 1);

  return (
    <div className="min-h-screen w-full bg-[#6B0F16] text-[#FAF6EE] flex flex-col items-center justify-between p-6 md:p-10">
      <div className="text-center max-w-lg pt-2">
        <h1 className="font-display italic text-4xl sm:text-5xl text-[#FAF6EE] mb-2">
          A Bouquet for You
        </h1>
        <p className="text-sm text-[#F3DFC1]/85">
          {bloomed
            ? 'Setiap kelopak menyimpan pesan kecil tentang dirimu.'
            : 'Klik buket bunga di bawah ini untuk memunculkan pesan spesial.'}
        </p>
      </div>

      <div className="w-full max-w-5xl my-auto py-8 grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] items-center gap-8">
        {/* Left column affirmations on desktop */}
        <div className="hidden md:flex flex-col items-end gap-5">
          <AnimatePresence>
            {bloomed &&
              leftItems.map((text, idx) => (
                <motion.div
                  key={`l-${idx}-${text}`}
                  initial={{ opacity: 0, x: 24, scale: 0.94 }}
                  animate={{ opacity: 1, x: 0, scale: 1 }}
                  exit={{ opacity: 0, x: 16, scale: 0.94 }}
                  transition={{ duration: 0.35, delay: idx * 0.08 }}
                  className="max-w-[230px] bg-[#FAF6EE] text-[#7A1318] rounded-xl px-5 py-3.5 shadow-[0_12px_28px_rgba(0,0,0,0.28)] font-display italic text-lg text-right"
                >
                  {text}
                </motion.div>
              ))}
          </AnimatePresence>
        </div>

        {/* Center interactive bouquet */}
        <div className="flex flex-col items-center justify-center">
          <button
            type="button"
            onClick={() => setBloomed((prev) => !prev)}
            aria-pressed={bloomed}
            aria-label={bloomed ? 'Tutup pesan bunga' : 'Buka pesan di sekitar bunga'}
            className="cursor-pointer rounded-3xl p-2 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#F5DFC0]"
          >
            <BouquetIllustration bloomed={bloomed} />
          </button>
          <span className="mt-3 font-display italic text-lg text-[#F5DFC0]">
            {bloomed ? 'Klik lagi untuk merapikan' : 'Click the flower!'}
          </span>
        </div>

        {/* Right column affirmations on desktop */}
        <div className="hidden md:flex flex-col items-start gap-5">
          <AnimatePresence>
            {bloomed &&
              rightItems.map((text, idx) => (
                <motion.div
                  key={`r-${idx}-${text}`}
                  initial={{ opacity: 0, x: -24, scale: 0.94 }}
                  animate={{ opacity: 1, x: 0, scale: 1 }}
                  exit={{ opacity: 0, x: -16, scale: 0.94 }}
                  transition={{ duration: 0.35, delay: idx * 0.08 + 0.04 }}
                  className="max-w-[230px] bg-[#FAF6EE] text-[#7A1318] rounded-xl px-5 py-3.5 shadow-[0_12px_28px_rgba(0,0,0,0.28)] font-display italic text-lg text-left"
                >
                  {text}
                </motion.div>
              ))}
          </AnimatePresence>
        </div>

        {/* Mobile affirmations grid */}
        <AnimatePresence>
          {bloomed && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:hidden"
            >
              {compliments.map((text, idx) => (
                <div
                  key={`m-${idx}`}
                  className="bg-[#FAF6EE] text-[#7A1318] rounded-xl px-4 py-3 shadow-md font-display italic text-base text-center"
                >
                  {text}
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="pb-2">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 py-2.5 px-6 rounded-xl bg-[#FAF6EE] text-[#6B0F16] text-sm font-semibold hover:bg-[#EFE6D6] transition-colors whitespace-nowrap shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#F5DFC0]"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Menu</span>
        </button>
      </div>
    </div>
  );
}
