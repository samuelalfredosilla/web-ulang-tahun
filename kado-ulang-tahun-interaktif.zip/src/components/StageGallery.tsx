import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Pause, Play, X } from 'lucide-react';
import { MemoryItem, MusicSource } from '../types/gift';
import { BirthdayAudioPlayer } from '../lib/audioEngine';
import { PolaroidArt } from './Artwork';

interface StageGalleryProps {
  memories: MemoryItem[];
  musicTitle: string;
  musicSource: MusicSource;
  musicUrl: string;
  onBack: () => void;
}

export function StageGallery({
  memories,
  musicTitle,
  musicSource,
  musicUrl,
  onBack,
}: StageGalleryProps) {
  const [selectedMemory, setSelectedMemory] = useState<MemoryItem | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const playerRef = useRef<BirthdayAudioPlayer | null>(null);

  useEffect(() => {
    playerRef.current = new BirthdayAudioPlayer();
    return () => {
      playerRef.current?.dispose();
      playerRef.current = null;
    };
  }, []);

  useEffect(() => {
    function handleEsc(e: KeyboardEvent) {
      if (e.key === 'Escape') setSelectedMemory(null);
    }
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, []);

  async function toggleMusic() {
    if (!playerRef.current) return;
    if (isPlaying) {
      playerRef.current.stop();
      setIsPlaying(false);
    } else {
      await playerRef.current.start(musicSource, musicUrl);
      setIsPlaying(true);
    }
  }

  function handleBack() {
    playerRef.current?.stop();
    setIsPlaying(false);
    onBack();
  }

  const gridColsClass =
    memories.length <= 2
      ? 'grid-cols-1 sm:grid-cols-2 max-w-xl'
      : memories.length === 3
      ? 'grid-cols-1 sm:grid-cols-3 max-w-3xl'
      : memories.length === 4
      ? 'grid-cols-2 lg:grid-cols-4 max-w-5xl'
      : 'grid-cols-2 sm:grid-cols-3 max-w-4xl';

  return (
    <div className="min-h-screen w-full bg-[#6B0F16] text-[#FAF6EE] flex flex-col items-center justify-between p-6 md:p-10">
      <div className="text-center max-w-xl pt-2">
        <h1 className="font-display italic text-4xl sm:text-5xl text-[#FAF6EE] mb-2">
          Memories &amp; Melody
        </h1>
        <p className="text-sm text-[#F3DFC1]/85">
          Klik foto polaroid untuk memperbesar, dan putar piringan hitam untuk mendengarkan lagu.
        </p>
      </div>

      {/* Polaroid Grid */}
      <div className={`w-full mx-auto my-8 grid ${gridColsClass} gap-6 items-center justify-items-center`}>
        {memories.map((item, idx) => {
          const tiltClass = idx % 2 === 0 ? '-rotate-2' : 'rotate-2';
          return (
            <motion.button
              key={item.id}
              type="button"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: idx * 0.07 }}
              onClick={() => setSelectedMemory(item)}
              className={`w-full max-w-[210px] bg-white text-[#241617] p-3 pb-5 rounded-sm shadow-[0_14px_30px_rgba(0,0,0,0.34)] ${tiltClass} hover:rotate-0 hover:scale-105 transition-transform duration-200 cursor-pointer text-left focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#F5DFC0]`}
            >
              <div className="aspect-square w-full overflow-hidden bg-[#EFE7DA] mb-3">
                <PolaroidArt
                  presetArt={item.presetArt}
                  imageData={item.imageData}
                  caption={item.caption}
                />
              </div>
              <p className="font-display italic text-base text-[#7A1318] leading-snug truncate">
                {item.caption}
              </p>
              {item.dateLabel && (
                <p className="text-xs text-[#6B5455] mt-0.5 truncate">{item.dateLabel}</p>
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Vinyl Player */}
      <div className="w-full max-w-md bg-[#560B11] border border-[#FAF6EE]/15 rounded-2xl p-5 flex items-center gap-5 shadow-[0_14px_35px_rgba(0,0,0,0.3)]">
        <button
          type="button"
          onClick={toggleMusic}
          aria-label={isPlaying ? 'Jeda musik' : 'Putar musik'}
          className="relative w-20 h-20 shrink-0 cursor-pointer group focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#F5DFC0] rounded-full"
        >
          {/* Vinyl disc */}
          <div
            className={`w-20 h-20 rounded-full bg-[#171213] border-2 border-[#382B2D] flex items-center justify-center shadow-lg ${
              isPlaying ? 'animate-vinyl-spin' : ''
            }`}
          >
            <div className="w-14 h-14 rounded-full border border-white/10 flex items-center justify-center">
              <div className="w-7 h-7 rounded-full bg-[#B9222A] flex items-center justify-center">
                <div className="w-2.5 h-2.5 rounded-full bg-[#FAF6EE]" />
              </div>
            </div>
          </div>

          {/* Tonearm */}
          <div
            className={`absolute -top-1 -right-1 w-8 h-2 bg-[#D6A438] rounded-full origin-right transition-transform duration-300 pointer-events-none ${
              isPlaying ? '-rotate-[28deg]' : '-rotate-[52deg]'
            }`}
          />
        </button>

        <div className="flex-1 min-w-0">
          <p className="text-xs text-[#F3DFC1]/75">Soundtrack Ulang Tahun</p>
          <p className="font-display italic text-xl text-[#FAF6EE] truncate">{musicTitle}</p>
          <p className="text-xs text-[#F3DFC1]/85 mt-0.5">
            {isPlaying ? 'Sedang diputar · Klik piringan untuk jeda' : 'Klik piringan hitam untuk memutar'}
          </p>
        </div>

        <button
          type="button"
          onClick={toggleMusic}
          aria-label={isPlaying ? 'Jeda lagu' : 'Putar lagu'}
          className="w-11 h-11 rounded-xl bg-[#FAF6EE] text-[#6B0F16] flex items-center justify-center shrink-0 hover:bg-[#EFE6D6] transition-colors cursor-pointer"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
        </button>
      </div>

      <div className="mt-7 pb-1">
        <button
          type="button"
          onClick={handleBack}
          className="inline-flex items-center gap-2 py-2.5 px-6 rounded-xl bg-[#FAF6EE] text-[#6B0F16] text-sm font-semibold hover:bg-[#EFE6D6] transition-colors whitespace-nowrap shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#F5DFC0]"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Menu</span>
        </button>
      </div>

      {/* Polaroid Lightbox Modal */}
      <AnimatePresence>
        {selectedMemory && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedMemory(null)}
            className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-6"
          >
            <motion.div
              initial={{ scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.94, opacity: 0 }}
              transition={{ duration: 0.2 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-md w-full bg-white text-[#241617] p-4 pb-6 rounded-sm shadow-2xl"
            >
              <button
                type="button"
                onClick={() => setSelectedMemory(null)}
                aria-label="Tutup foto"
                className="absolute -top-4 -right-4 w-10 h-10 rounded-full bg-[#FAF6EE] text-[#6B0F16] shadow-lg flex items-center justify-center hover:bg-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="aspect-square w-full overflow-hidden bg-[#EFE7DA] mb-4">
                <PolaroidArt
                  presetArt={selectedMemory.presetArt}
                  imageData={selectedMemory.imageData}
                  caption={selectedMemory.caption}
                />
              </div>
              <h2 className="font-display italic text-2xl text-[#7A1318]">
                {selectedMemory.caption}
              </h2>
              {selectedMemory.dateLabel && (
                <p className="text-xs text-[#6B5455] mt-1">{selectedMemory.dateLabel}</p>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
