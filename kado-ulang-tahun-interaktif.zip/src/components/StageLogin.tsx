import React, { useRef, useState } from 'react';
import { motion } from 'motion/react';
import { Eye, EyeOff, Sparkles, AlertCircle, KeyRound } from 'lucide-react';
import { BirthdayGift } from '../types/gift';
import { WaxSealEmblem } from './Artwork';

interface StageLoginProps {
  gift: BirthdayGift;
  loadingGift: boolean;
  giftLoadError: string | null;
  onUnlock: (pin: string) => Promise<boolean>;
  onOpenStudio: () => void;
}

const PIN_LENGTH = 6;

export function StageLogin({
  gift,
  loadingGift,
  giftLoadError,
  onUnlock,
  onOpenStudio,
}: StageLoginProps) {
  const [digits, setDigits] = useState<string[]>(Array(PIN_LENGTH).fill(''));
  const [showPin, setShowPin] = useState(false);
  const [checking, setChecking] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showHint, setShowHint] = useState(false);
  const [shakeKey, setShakeKey] = useState(0);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const pinValue = digits.join('');

  async function submitPin(code: string) {
    if (code.length < PIN_LENGTH) {
      setErrorMsg('Masukkan 6 digit PIN terlebih dahulu ya.');
      setShakeKey((k) => k + 1);
      return;
    }
    setChecking(true);
    setErrorMsg('');
    try {
      const ok = await onUnlock(code);
      if (!ok) {
        setErrorMsg('PIN salah, coba lagi ya!');
        setDigits(Array(PIN_LENGTH).fill(''));
        setShakeKey((k) => k + 1);
        window.setTimeout(() => {
          inputRefs.current[0]?.focus();
        }, 50);
      }
    } finally {
      setChecking(false);
    }
  }

  function handleDigitChange(index: number, rawValue: string) {
    const cleaned = rawValue.replace(/\D/g, '');
    if (!cleaned) {
      const next = [...digits];
      next[index] = '';
      setDigits(next);
      if (errorMsg) setErrorMsg('');
      return;
    }

    if (cleaned.length > 1) {
      const next = [...digits];
      for (let i = 0; i < cleaned.length && index + i < PIN_LENGTH; i++) {
        next[index + i] = cleaned[i];
      }
      setDigits(next);
      if (errorMsg) setErrorMsg('');
      const focusIdx = Math.min(index + cleaned.length, PIN_LENGTH - 1);
      inputRefs.current[focusIdx]?.focus();
      return;
    }

    const next = [...digits];
    next[index] = cleaned;
    setDigits(next);
    if (errorMsg) setErrorMsg('');

    if (index < PIN_LENGTH - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  }

  function handleKeyDown(index: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Backspace') {
      if (digits[index]) {
        const next = [...digits];
        next[index] = '';
        setDigits(next);
      } else if (index > 0) {
        const next = [...digits];
        next[index - 1] = '';
        setDigits(next);
        inputRefs.current[index - 1]?.focus();
      }
      e.preventDefault();
    } else if (e.key === 'ArrowLeft' && index > 0) {
      inputRefs.current[index - 1]?.focus();
    } else if (e.key === 'ArrowRight' && index < PIN_LENGTH - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  }

  function handlePaste(e: React.ClipboardEvent<HTMLInputElement>) {
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, PIN_LENGTH);
    if (!pasted) return;
    e.preventDefault();
    const next = Array(PIN_LENGTH).fill('');
    for (let i = 0; i < pasted.length; i++) {
      next[i] = pasted[i];
    }
    setDigits(next);
    if (errorMsg) setErrorMsg('');
    const focusIdx = Math.min(pasted.length, PIN_LENGTH - 1);
    inputRefs.current[focusIdx]?.focus();
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    void submitPin(pinValue);
  }

  return (
    <div className="min-h-screen w-full bg-[#F6F1E7] text-[#241617] flex flex-col justify-between p-6 md:p-10">
      <header className="w-full max-w-5xl mx-auto flex items-center justify-between gap-4">
        <span className="font-display text-lg font-semibold text-[#7A1318] whitespace-nowrap shrink-0">
          Kado Digital
        </span>
        <button
          type="button"
          onClick={onOpenStudio}
          className="inline-flex items-center gap-2 py-2 px-4 rounded-lg border border-[#7A1318]/25 bg-white/80 text-[#7A1318] text-sm font-medium hover:bg-white transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#7A1318]"
        >
          <KeyRound className="w-4 h-4" />
          <span>Kelola &amp; Sesuaikan Kado</span>
        </button>
      </header>

      <main className="flex-1 flex items-center justify-center py-8">
        <motion.div
          key={shakeKey}
          initial={{ opacity: 0, y: 12 }}
          animate={
            shakeKey > 0
              ? { opacity: 1, y: 0, x: [0, -8, 8, -6, 6, 0] }
              : { opacity: 1, y: 0 }
          }
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-md bg-white rounded-2xl p-8 sm:p-10 shadow-[0_20px_50px_rgba(107,15,22,0.12)] border border-[#7A1318]/10 text-center"
        >
          <div className="flex justify-center mb-5">
            <WaxSealEmblem className="w-16 h-16" />
          </div>

          <p className="text-xs font-medium text-[#7A1318]/80 mb-2">
            Untuk {gift.recipientName} <span aria-hidden="true">·</span> Dari {gift.senderName}
          </p>

          <h1 className="font-display italic text-4xl sm:text-5xl text-[#7A1318] mb-3 text-balance">
            Hello there!
          </h1>

          <p className="text-sm text-[#5C4546] leading-relaxed mb-6">
            Masukkan 6 digit PIN untuk membuka kado ulang tahun ini.
          </p>

          {loadingGift ? (
            <div className="py-6 text-sm text-[#5C4546]">Memuat kado dari Firebase...</div>
          ) : giftLoadError ? (
            <div className="mb-5 p-3 rounded-lg bg-[#FDF2F2] border border-[#C42B33]/25 text-xs text-[#8B151B] flex items-center gap-2 text-left">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{giftLoadError}</span>
            </div>
          ) : null}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <div className="flex items-center justify-center gap-2 sm:gap-2.5">
                {digits.map((digit, index) => (
                  <input
                    key={index}
                    ref={(el) => {
                      inputRefs.current[index] = el;
                    }}
                    type={showPin ? 'text' : 'password'}
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleDigitChange(index, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(index, e)}
                    onPaste={handlePaste}
                    aria-label={`Digit PIN ke-${index + 1}`}
                    className="w-11 h-13 sm:w-12 sm:h-14 text-center text-xl font-semibold tabular-nums rounded-xl border border-[#DFD5C5] bg-[#FAF7F2] text-[#7A1318] focus:outline-none focus:border-[#7A1318] focus:bg-white transition-colors"
                  />
                ))}
              </div>

              <div className="mt-3 flex justify-center">
                <button
                  type="button"
                  onClick={() => setShowPin((prev) => !prev)}
                  className="inline-flex items-center gap-1.5 text-xs text-[#5C4546] hover:text-[#7A1318] py-1 px-2 rounded-md cursor-pointer"
                >
                  {showPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{showPin ? 'Sembunyikan angka PIN' : 'Tampilkan angka PIN'}</span>
                </button>
              </div>
            </div>

            {errorMsg && (
              <div
                role="alert"
                className="flex items-center justify-center gap-2 text-xs font-medium text-[#B41E25]"
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={checking || loadingGift}
              className="w-full py-3 px-6 rounded-xl bg-[#7A1318] text-[#FAF6EE] text-sm font-semibold hover:bg-[#5E0E12] disabled:opacity-60 transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#7A1318] cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>{checking ? 'Memeriksa PIN...' : 'Buka Kado'}</span>
            </button>
          </form>

          {gift.passcodeHint && (
            <div className="mt-5 pt-4 border-t border-[#EFE7DA]">
              <button
                type="button"
                onClick={() => setShowHint((prev) => !prev)}
                className="text-xs font-medium text-[#7A1318]/80 hover:text-[#7A1318] underline underline-offset-4 cursor-pointer"
              >
                {showHint ? 'Sembunyikan petunjuk' : 'Butuh petunjuk PIN?'}
              </button>
              {showHint && (
                <p className="mt-2 text-xs text-[#5C4546] bg-[#FAF6EE] rounded-lg py-2 px-3">
                  {gift.passcodeHint}
                </p>
              )}
            </div>
          )}
        </motion.div>
      </main>

      <footer className="text-center text-xs text-[#7A1318]/65">
        Keepsake Ulang Tahun <span aria-hidden="true">·</span> Tersimpan aman dengan Firebase
      </footer>
    </div>
  );
}
