import React from 'react';
import { motion } from 'motion/react';
import { Lock, Settings2 } from 'lucide-react';
import { GiftStage } from '../types/gift';
import { MenuCardIcon } from './Artwork';

interface StageMenuProps {
  title: string;
  recipientName: string;
  onSelectStage: (stage: GiftStage) => void;
  onLockGift: () => void;
  onOpenStudio: () => void;
}

export function StageMenu({
  title,
  recipientName,
  onSelectStage,
  onLockGift,
  onOpenStudio,
}: StageMenuProps) {
  const items: {
    stage: GiftStage;
    type: 'message' | 'flower' | 'gallery';
    label: string;
    subtitle: string;
  }[] = [
    {
      stage: 'message',
      type: 'message',
      label: 'Message',
      subtitle: 'Surat ucapan spesial untukmu',
    },
    {
      stage: 'flower',
      type: 'flower',
      label: 'Flower',
      subtitle: 'Buket bunga & pesan penyemangat',
    },
    {
      stage: 'gallery',
      type: 'gallery',
      label: 'Gallery & Music',
      subtitle: 'Kenangan polaroid & alunan melodi',
    },
  ];

  return (
    <div className="min-h-screen w-full bg-[#6B0F16] text-[#FAF6EE] flex flex-col justify-between p-6 md:p-10">
      <header className="w-full max-w-5xl mx-auto flex items-center justify-between gap-4">
        <span className="font-display italic text-xl text-[#F5DFC0] whitespace-nowrap shrink-0">
          Untuk {recipientName}
        </span>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenStudio}
            className="inline-flex items-center gap-2 py-2 px-4 rounded-lg border border-[#FAF6EE]/25 text-xs font-medium text-[#FAF6EE] hover:bg-white/10 transition-colors whitespace-nowrap shrink-0"
          >
            <Settings2 className="w-3.5 h-3.5" />
            <span>Studio Kado</span>
          </button>
          <button
            type="button"
            onClick={onLockGift}
            className="inline-flex items-center gap-2 py-2 px-4 rounded-lg bg-[#FAF6EE] text-[#6B0F16] text-xs font-semibold hover:bg-[#EFE6D6] transition-colors whitespace-nowrap shrink-0"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Kunci Kado</span>
          </button>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center py-10">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-4xl text-center"
        >
          <h1 className="font-display italic text-4xl sm:text-5xl md:text-6xl text-[#FAF6EE] mb-4 text-balance">
            {title}
          </h1>
          <p className="text-sm text-[#F3DFC1]/85 mb-10 max-w-md mx-auto">
            Pilih salah satu kado di bawah ini untuk melihat kejutan yang sudah disiapkan.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {items.map((item, index) => (
              <motion.button
                key={item.stage}
                type="button"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: index * 0.08 }}
                onClick={() => onSelectStage(item.stage)}
                className="group bg-[#FAF6EE] text-[#241617] rounded-2xl p-8 shadow-[0_18px_40px_rgba(0,0,0,0.28)] hover:-translate-y-1.5 transition-transform duration-200 flex flex-col items-center text-center cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#F5DFC0]"
              >
                <div className="w-24 h-24 rounded-2xl bg-[#F2E9DA] flex items-center justify-center mb-5 group-hover:scale-105 transition-transform duration-200">
                  <MenuCardIcon type={item.type} />
                </div>
                <span className="font-display text-2xl font-semibold text-[#7A1318] mb-1.5">
                  {item.label}
                </span>
                <span className="text-xs text-[#5C4546] leading-relaxed">
                  {item.subtitle}
                </span>
              </motion.button>
            ))}
          </div>
        </motion.div>
      </main>

      <footer className="text-center text-xs text-[#F3DFC1]/65">
        Pilih salah satu kartu untuk membuka setiap bagian kado
      </footer>
    </div>
  );
}
