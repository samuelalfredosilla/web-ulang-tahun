import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft } from 'lucide-react';
import { WaxSealEmblem } from './Artwork';

interface StageMessageProps {
  letterTitle: string;
  letterBody: string;
  senderName: string;
  onBack: () => void;
}

export function StageMessage({
  letterTitle,
  letterBody,
  senderName,
  onBack,
}: StageMessageProps) {
  const paragraphs = letterBody
    .split(/\n{2,}/)
    .map((p) => p.trim())
    .filter(Boolean);

  return (
    <div className="min-h-screen w-full bg-[#6B0F16] text-[#FAF6EE] flex flex-col items-center justify-center p-6 md:p-10">
      <motion.article
        initial={{ opacity: 0, y: 18, rotate: -1.5 }}
        animate={{ opacity: 1, y: 0, rotate: -1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-2xl bg-[#FAF6EE] text-[#2B1B1C] rounded-xl p-8 sm:p-12 shadow-[0_24px_60px_rgba(0,0,0,0.38)] border border-[#E5D7C3]"
      >
        <div className="absolute -top-5 right-8 pointer-events-none">
          <WaxSealEmblem className="w-12 h-12 drop-shadow-md" />
        </div>

        <h1 className="font-display italic text-3xl sm:text-4xl text-[#7A1318] mb-6">
          {letterTitle}
        </h1>

        <div className="paper-lines space-y-5 text-[15px] sm:text-base leading-[32px] text-[#352324]">
          {paragraphs.map((para, index) => (
            <p key={index} className="whitespace-pre-line">
              {para}
            </p>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t border-[#7A1318]/15 flex items-center justify-between gap-4">
          <span className="font-display italic text-xl text-[#7A1318]">
            With love, {senderName}
          </span>
        </div>
      </motion.article>

      <div className="mt-8">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 py-2.5 px-6 rounded-xl bg-[#FAF6EE] text-[#6B0F16] text-sm font-semibold hover:bg-[#EFE6D6] transition-colors whitespace-nowrap shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#F5DFC0]"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Menu</span>
        </button>
      </div>
    </div>
  );
}
