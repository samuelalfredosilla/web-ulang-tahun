export type PresetArt = 'cake' | 'sunset' | 'coffee' | 'stars' | 'custom';

export type MusicSource = 'melody' | 'custom_url';

export type GiftStage = 'login' | 'envelope' | 'menu' | 'message' | 'flower' | 'gallery';

export interface MemoryItem {
  id: string;
  caption: string;
  dateLabel: string;
  presetArt: PresetArt;
  imageData: string;
}

export interface BirthdayGift {
  id: string;
  ownerId: string;
  recipientName: string;
  senderName: string;
  passcodeHash: string;
  passcodeHint: string;
  envelopeTitle: string;
  menuTitle: string;
  letterTitle: string;
  letterBody: string;
  flowerCompliments: string[];
  memories: MemoryItem[];
  musicTitle: string;
  musicSource: MusicSource;
  musicUrl: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}
